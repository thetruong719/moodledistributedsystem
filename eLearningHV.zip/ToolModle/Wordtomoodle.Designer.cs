﻿namespace unzipPackage.ToolModle
{
    partial class Wordtomoodle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Wordtomoodle));
            this.btnCreate = new System.Windows.Forms.Button();
            this.lblphantram = new System.Windows.Forms.Label();
            this.probar = new System.Windows.Forms.ProgressBar();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDelay2 = new System.Windows.Forms.TextBox();
            this.txtDelay = new System.Windows.Forms.TextBox();
            this.btnSelectFile = new System.Windows.Forms.Button();
            this.txtPath = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtnoidung = new DevExpress.XtraRichEdit.RichEditControl();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnFolder = new System.Windows.Forms.Button();
            this.txtSavePath = new System.Windows.Forms.TextBox();
            this.txtAnswer = new System.Windows.Forms.TextBox();
            this.lblAnswer = new System.Windows.Forms.Label();
            this.chkFeedback = new System.Windows.Forms.CheckBox();
            this.chkRemoveNumbering = new System.Windows.Forms.CheckBox();
            this.chkAnswerInFile = new System.Windows.Forms.CheckBox();
            this.chkFolder = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.autoCatName = new System.Windows.Forms.CheckBox();
            this.catName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.clearFormat_checkBox = new System.Windows.Forms.CheckBox();
            this.probar1 = new System.Windows.Forms.ProgressBar();
            this.label3 = new System.Windows.Forms.Label();
            this.language_comboBox = new System.Windows.Forms.ComboBox();
            this.capnhat = new DevExpress.XtraSplashScreen.SplashScreenManager(this, typeof(global::unzipPackage.WaitForm1), true, true);
            this.fixedRowNum = new System.Windows.Forms.CheckBox();
            this.showFileContent = new System.Windows.Forms.CheckBox();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCreate
            // 
            this.btnCreate.Location = new System.Drawing.Point(153, 289);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(75, 23);
            this.btnCreate.TabIndex = 21;
            this.btnCreate.Text = "Tạo file";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
            // 
            // lblphantram
            // 
            this.lblphantram.AutoSize = true;
            this.lblphantram.Location = new System.Drawing.Point(138, 405);
            this.lblphantram.Name = "lblphantram";
            this.lblphantram.Size = new System.Drawing.Size(80, 13);
            this.lblphantram.TabIndex = 36;
            this.lblphantram.Text = "Tạo câu hỏi: %";
            this.lblphantram.Visible = false;
            // 
            // probar
            // 
            this.probar.Location = new System.Drawing.Point(15, 399);
            this.probar.Name = "probar";
            this.probar.Size = new System.Drawing.Size(371, 23);
            this.probar.TabIndex = 35;
            this.probar.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(278, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 34;
            this.label2.Text = "Độ trễ 2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(277, 134);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 33;
            this.label1.Text = "Độ trễ 1";
            // 
            // txtDelay2
            // 
            this.txtDelay2.Location = new System.Drawing.Point(332, 158);
            this.txtDelay2.Name = "txtDelay2";
            this.txtDelay2.Size = new System.Drawing.Size(44, 21);
            this.txtDelay2.TabIndex = 31;
            this.txtDelay2.Text = "150";
            // 
            // txtDelay
            // 
            this.txtDelay.Location = new System.Drawing.Point(332, 131);
            this.txtDelay.Name = "txtDelay";
            this.txtDelay.Size = new System.Drawing.Size(44, 21);
            this.txtDelay.TabIndex = 30;
            this.txtDelay.Text = "150";
            // 
            // btnSelectFile
            // 
            this.btnSelectFile.Location = new System.Drawing.Point(301, 20);
            this.btnSelectFile.Name = "btnSelectFile";
            this.btnSelectFile.Size = new System.Drawing.Size(75, 23);
            this.btnSelectFile.TabIndex = 20;
            this.btnSelectFile.Text = "Chọn file";
            this.btnSelectFile.UseVisualStyleBackColor = true;
            this.btnSelectFile.Click += new System.EventHandler(this.btnSelectFile_Click);
            // 
            // txtPath
            // 
            this.txtPath.Location = new System.Drawing.Point(6, 20);
            this.txtPath.Name = "txtPath";
            this.txtPath.Size = new System.Drawing.Size(290, 21);
            this.txtPath.TabIndex = 19;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.txtnoidung);
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(321, 437);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Hiển thị nội dung";
            // 
            // txtnoidung
            // 
            this.txtnoidung.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtnoidung.Location = new System.Drawing.Point(6, 20);
            this.txtnoidung.Name = "txtnoidung";
            this.txtnoidung.Size = new System.Drawing.Size(309, 411);
            this.txtnoidung.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Location = new System.Drawing.Point(404, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(321, 437);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Hiển thị file";
            // 
            // btnFolder
            // 
            this.btnFolder.Location = new System.Drawing.Point(301, 49);
            this.btnFolder.Name = "btnFolder";
            this.btnFolder.Size = new System.Drawing.Size(75, 23);
            this.btnFolder.TabIndex = 23;
            this.btnFolder.Text = "Nơi lưu";
            this.btnFolder.UseVisualStyleBackColor = true;
            this.btnFolder.Click += new System.EventHandler(this.btnFolder_Click);
            // 
            // txtSavePath
            // 
            this.txtSavePath.Location = new System.Drawing.Point(6, 51);
            this.txtSavePath.Name = "txtSavePath";
            this.txtSavePath.Size = new System.Drawing.Size(290, 21);
            this.txtSavePath.TabIndex = 24;
            // 
            // txtAnswer
            // 
            this.txtAnswer.Enabled = false;
            this.txtAnswer.Location = new System.Drawing.Point(9, 262);
            this.txtAnswer.Name = "txtAnswer";
            this.txtAnswer.Size = new System.Drawing.Size(369, 21);
            this.txtAnswer.TabIndex = 25;
            // 
            // lblAnswer
            // 
            this.lblAnswer.AutoSize = true;
            this.lblAnswer.Location = new System.Drawing.Point(5, 242);
            this.lblAnswer.Name = "lblAnswer";
            this.lblAnswer.Size = new System.Drawing.Size(42, 13);
            this.lblAnswer.TabIndex = 27;
            this.lblAnswer.Text = "Đáp án";
            // 
            // chkFeedback
            // 
            this.chkFeedback.AutoSize = true;
            this.chkFeedback.Checked = true;
            this.chkFeedback.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkFeedback.Enabled = false;
            this.chkFeedback.Location = new System.Drawing.Point(7, 130);
            this.chkFeedback.Name = "chkFeedback";
            this.chkFeedback.Size = new System.Drawing.Size(113, 17);
            this.chkFeedback.TabIndex = 22;
            this.chkFeedback.Text = "Giải thích lựa chọn";
            this.chkFeedback.UseVisualStyleBackColor = true;
            // 
            // chkRemoveNumbering
            // 
            this.chkRemoveNumbering.AutoSize = true;
            this.chkRemoveNumbering.Checked = true;
            this.chkRemoveNumbering.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkRemoveNumbering.Enabled = false;
            this.chkRemoveNumbering.Location = new System.Drawing.Point(7, 153);
            this.chkRemoveNumbering.Name = "chkRemoveNumbering";
            this.chkRemoveNumbering.Size = new System.Drawing.Size(98, 17);
            this.chkRemoveNumbering.TabIndex = 26;
            this.chkRemoveNumbering.Text = "Loại bỏ chỉ mục";
            this.chkRemoveNumbering.UseVisualStyleBackColor = true;
            // 
            // chkAnswerInFile
            // 
            this.chkAnswerInFile.AutoSize = true;
            this.chkAnswerInFile.Checked = true;
            this.chkAnswerInFile.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkAnswerInFile.Enabled = false;
            this.chkAnswerInFile.Location = new System.Drawing.Point(129, 132);
            this.chkAnswerInFile.Name = "chkAnswerInFile";
            this.chkAnswerInFile.Size = new System.Drawing.Size(138, 17);
            this.chkAnswerInFile.TabIndex = 29;
            this.chkAnswerInFile.Text = "Câu trả lời trong tập tin";
            this.chkAnswerInFile.UseVisualStyleBackColor = true;
            // 
            // chkFolder
            // 
            this.chkFolder.AutoSize = true;
            this.chkFolder.Enabled = false;
            this.chkFolder.Location = new System.Drawing.Point(281, 217);
            this.chkFolder.Name = "chkFolder";
            this.chkFolder.Size = new System.Drawing.Size(95, 17);
            this.chkFolder.TabIndex = 28;
            this.chkFolder.Text = "Choose Folder";
            this.chkFolder.UseVisualStyleBackColor = true;
            this.chkFolder.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.showFileContent);
            this.groupBox1.Controls.Add(this.fixedRowNum);
            this.groupBox1.Controls.Add(this.autoCatName);
            this.groupBox1.Controls.Add(this.catName);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.clearFormat_checkBox);
            this.groupBox1.Controls.Add(this.probar1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.language_comboBox);
            this.groupBox1.Controls.Add(this.btnCreate);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtDelay2);
            this.groupBox1.Controls.Add(this.txtDelay);
            this.groupBox1.Controls.Add(this.btnSelectFile);
            this.groupBox1.Controls.Add(this.txtPath);
            this.groupBox1.Controls.Add(this.btnFolder);
            this.groupBox1.Controls.Add(this.txtSavePath);
            this.groupBox1.Controls.Add(this.chkFolder);
            this.groupBox1.Controls.Add(this.txtAnswer);
            this.groupBox1.Controls.Add(this.lblAnswer);
            this.groupBox1.Controls.Add(this.chkFeedback);
            this.groupBox1.Controls.Add(this.chkRemoveNumbering);
            this.groupBox1.Controls.Add(this.chkAnswerInFile);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(386, 366);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Word to moodle";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // autoCatName
            // 
            this.autoCatName.AutoSize = true;
            this.autoCatName.Checked = true;
            this.autoCatName.CheckState = System.Windows.Forms.CheckState.Checked;
            this.autoCatName.Location = new System.Drawing.Point(9, 97);
            this.autoCatName.Name = "autoCatName";
            this.autoCatName.Size = new System.Drawing.Size(15, 14);
            this.autoCatName.TabIndex = 42;
            this.autoCatName.UseVisualStyleBackColor = true;
            // 
            // catName
            // 
            this.catName.Location = new System.Drawing.Point(55, 78);
            this.catName.Multiline = true;
            this.catName.Name = "catName";
            this.catName.Size = new System.Drawing.Size(321, 46);
            this.catName.TabIndex = 41;
            this.catName.MouseClick += new System.Windows.Forms.MouseEventHandler(this.catName_MouseClick);
            this.catName.TextChanged += new System.EventHandler(this.catName_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 81);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 13);
            this.label5.TabIndex = 40;
            this.label5.Text = "Đề mục:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(141, 332);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Tạo câu hỏi: %";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // clearFormat_checkBox
            // 
            this.clearFormat_checkBox.AutoSize = true;
            this.clearFormat_checkBox.Checked = true;
            this.clearFormat_checkBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.clearFormat_checkBox.Enabled = false;
            this.clearFormat_checkBox.Location = new System.Drawing.Point(129, 154);
            this.clearFormat_checkBox.Name = "clearFormat_checkBox";
            this.clearFormat_checkBox.Size = new System.Drawing.Size(100, 17);
            this.clearFormat_checkBox.TabIndex = 39;
            this.clearFormat_checkBox.Text = "Xóa hết Format";
            this.clearFormat_checkBox.UseVisualStyleBackColor = true;
            // 
            // probar1
            // 
            this.probar1.Location = new System.Drawing.Point(9, 330);
            this.probar1.Name = "probar1";
            this.probar1.Size = new System.Drawing.Size(365, 23);
            this.probar1.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 216);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 38;
            this.label3.Text = "Ngôn ngữ:";
            // 
            // language_comboBox
            // 
            this.language_comboBox.FormattingEnabled = true;
            this.language_comboBox.Items.AddRange(new object[] {
            "Tiếng Anh",
            "Tiếng Việt"});
            this.language_comboBox.Location = new System.Drawing.Point(70, 213);
            this.language_comboBox.Name = "language_comboBox";
            this.language_comboBox.Size = new System.Drawing.Size(121, 21);
            this.language_comboBox.TabIndex = 37;
            this.language_comboBox.Text = "Tiếng Anh";
            // 
            // capnhat
            // 
            this.capnhat.ClosingDelay = 500;
            // 
            // fixedRowNum
            // 
            this.fixedRowNum.AutoSize = true;
            this.fixedRowNum.Checked = true;
            this.fixedRowNum.CheckState = System.Windows.Forms.CheckState.Checked;
            this.fixedRowNum.Location = new System.Drawing.Point(6, 176);
            this.fixedRowNum.Name = "fixedRowNum";
            this.fixedRowNum.Size = new System.Drawing.Size(121, 17);
            this.fixedRowNum.TabIndex = 43;
            this.fixedRowNum.Text = "Kiểm tra đủ số dòng";
            this.fixedRowNum.UseVisualStyleBackColor = true;
            // 
            // showFileContent
            // 
            this.showFileContent.AutoSize = true;
            this.showFileContent.Checked = true;
            this.showFileContent.CheckState = System.Windows.Forms.CheckState.Checked;
            this.showFileContent.Location = new System.Drawing.Point(129, 177);
            this.showFileContent.Name = "showFileContent";
            this.showFileContent.Size = new System.Drawing.Size(124, 17);
            this.showFileContent.TabIndex = 44;
            this.showFileContent.Text = "Xem nội dung tập tin";
            this.showFileContent.UseVisualStyleBackColor = true;
            // 
            // Wordtomoodle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(737, 461);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblphantram);
            this.Controls.Add(this.probar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Wordtomoodle";
            this.Text = "Word to moodle";
            this.Load += new System.EventHandler(this.Wordtomoodle_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.Label lblphantram;
        private System.Windows.Forms.ProgressBar probar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDelay2;
        private System.Windows.Forms.TextBox txtDelay;
        private System.Windows.Forms.Button btnSelectFile;
        private System.Windows.Forms.TextBox txtPath;
        private System.Windows.Forms.GroupBox groupBox3;
        private DevExpress.XtraRichEdit.RichEditControl txtnoidung;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnFolder;
        private System.Windows.Forms.TextBox txtSavePath;
        private System.Windows.Forms.TextBox txtAnswer;
        private System.Windows.Forms.Label lblAnswer;
        private System.Windows.Forms.CheckBox chkFeedback;
        private System.Windows.Forms.CheckBox chkRemoveNumbering;
        private System.Windows.Forms.CheckBox chkAnswerInFile;
        private System.Windows.Forms.CheckBox chkFolder;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox language_comboBox;
        private System.Windows.Forms.CheckBox clearFormat_checkBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ProgressBar probar1;
        private DevExpress.XtraSplashScreen.SplashScreenManager capnhat;
        private System.Windows.Forms.TextBox catName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox autoCatName;
        private System.Windows.Forms.CheckBox fixedRowNum;
        private System.Windows.Forms.CheckBox showFileContent;
    }
}