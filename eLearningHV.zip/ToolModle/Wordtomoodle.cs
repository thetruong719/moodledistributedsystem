﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Word;
using Microsoft.Office.Core;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Diagnostics;


namespace unzipPackage.ToolModle
{
    public partial class Wordtomoodle : DevExpress.XtraEditors.XtraForm
    {
        String[] FilesSelected;
        public Wordtomoodle()
        {
            InitializeComponent();
            label4.Visible = false;
            probar1.Visible = false;
        }

        private void Wordtomoodle_Load(object sender, EventArgs e)
        {

        }

        private void btnSelectFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = "Excel File Dialog";
            //fdlg.InitialDirectory = @"c:\";
            fdlg.Filter = "All files (*.*)|*.*|Word Documents (*.docx; *.doc)|*.docx*; *.doc*";
            fdlg.FilterIndex = 2;
            fdlg.Multiselect = true;
            fdlg.RestoreDirectory = true;
            DialogResult result = fdlg.ShowDialog();
            if (result == DialogResult.OK)
            {
                //txtPath.Text = fdlg.FileName;
                //String[] Files = fdlg.FileNames;// d.GetFiles("*.docx");
                FilesSelected = fdlg.FileNames;
                //StandardizedWordsDocument(Files);

                txtPath.Text = FilesSelected[0].ToString();//fdlg.FileName;
                capnhat.ShowWaitForm();
                txtnoidung.LoadDocument(txtPath.Text);
                capnhat.CloseWaitForm();

                //cat name
                catName.Text = ConvertToUnSign(Path.GetFileNameWithoutExtension(txtPath.Text));
            }

            
            /*
            if (!chkFolder.Checked)
            {
                txtSavePath.Text = "";
                OpenFileDialog fdlg = new OpenFileDialog();
                fdlg.Title = "Excel File Dialog";
                //fdlg.InitialDirectory = @"c:\";
                fdlg.Filter = "All files (*.*)|*.*|Word Documents (*.docx; *.doc)|*.docx*; *.doc*";
                fdlg.FilterIndex = 2;
                fdlg.RestoreDirectory = true;
                DialogResult result = fdlg.ShowDialog();
                if (result == DialogResult.OK)
                {
                    txtPath.Text = fdlg.FileName;
                    capnhat.ShowWaitForm();
                    txtnoidung.LoadDocument(txtPath.Text);
                    capnhat.CloseWaitForm();
                }
            }
            else
            {
                txtSavePath.Text = "";
                FolderBrowserDialog folder = new FolderBrowserDialog();

                DialogResult result = new DialogResult();
                result = folder.ShowDialog();
                if (result == DialogResult.OK)
                {
                    txtPath.Text = folder.SelectedPath;
                }
            }*/
        }

        private void btnFolder_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folder = new FolderBrowserDialog();
            DialogResult result = folder.ShowDialog();
            if (result == DialogResult.OK)
            {
                txtSavePath.Text = folder.SelectedPath;
            }
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            Process[] processlist = Process.GetProcesses();
            foreach (Process theprocess in processlist)
            {
                if (theprocess.ProcessName.ToString().IndexOf("WINWORD") >= 0)
                    theprocess.Kill();
            }

            foreach (string fileName in FilesSelected)
            {
                txtPath.Text = fileName;// FilesSelected[0].ToString();//fdlg.FileName;
                txtSavePath.Text = Directory.GetParent(fileName).ToString(); //Directory.GetCurrentDirectory().ToString();
                if (showFileContent.Checked == true)
                {
                    capnhat.ShowWaitForm();

                    txtnoidung.LoadDocument(txtPath.Text);
                    capnhat.CloseWaitForm();
                }
                //catName.Text = ConvertToUnSign(Path.GetFileNameWithoutExtension(txtPath.Text));
                CreateWordDocument();
                autoCatName.Checked = true;
                
            }
            MessageBox.Show("Đã tạo tệp thành công!", "Thông báo!");
        }
        private void CreateWordDocument()
        {
            capnhat.ShowWaitForm();
            bool ktloi = false;
            //Create an instance for word app  
            Microsoft.Office.Interop.Word.Application winword = new Microsoft.Office.Interop.Word.Application();

            //Set animation status for word application  
            //!winword.ShowAnimation = false;

            //Set status for word application is to be visible or not.  
            //!winword.Visible = false;

            //Create a missing variable for missing value  
            object missing = Missing.Value;

            object readOnly = true;
            //object readOnlyTemplate = true;
            object isVisible = false;
            object fileName = @txtPath.Text;
            string workingDirectory = Environment.CurrentDirectory;
            string workingDirectory_ = workingDirectory;
            string runningPath = Directory.GetParent(workingDirectory).ToString();
            //runningPath = Directory.GetParent(runningPath).Parent.FullName+"\\Test\\";
            string template_M2W;
            if (language_comboBox.Text == "Tiếng Anh")
                template_M2W = Directory.GetCurrentDirectory().ToString() + @"\Template\M2W.docx";
            else
                template_M2W = Directory.GetCurrentDirectory().ToString() + @"\Template\M2W_vi.docx";
            object fileName2 = @Path.Combine(runningPath, template_M2W);
            //Microsoft.Office.Interop.Word.Paragraph para1 = document.Content.Paragraphs.Add(ref missing);

            Document document2;
            

            //Create a new document  
            Document document = winword.Documents.Add(ref missing, ref missing, ref missing, ref missing);
            document2 = winword.Documents.Open(ref fileName, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref isVisible, ref missing, ref missing, ref missing, ref missing);
            //MessageBox.Show(fileName2.ToString());
            //Document document3 = winword.Documents.Open(ref fileName2, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref isVisible, ref missing, ref missing, ref missing, ref missing);
            Document document3 = winword.Documents.Open(@workingDirectory_+"\\Template\\M2W_vi.docx", ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref isVisible, ref missing, ref missing, ref missing, ref missing);

            //Add paragraph with Heading 1 style  
            //Microsoft.Office.Interop.Word.Paragraph para1 = document.Content.Paragraphs.Add(ref missing);
            try
            {
                //Create a 5X5 table and insert some dummy record  
                //Microsoft.Office.Interop.Word.Table firstTable = document.Tables.Add(para1.Range, 1, 1, ref missing, ref missing);

                Table questionTable = document2.Tables[1];
                Table templateTable = document3.Tables[1];
                object start = document2.Content.Start;
                object end = document2.Content.End;

                if (questionTable.Rows.Count % 7 == 0)
                {
                    
                    /* xóa các tên đáp án.
                    if (chkRemoveNumbering.Checked)
                    {                        
                        document2.Range(start, end).Select();
                        document2.Range(start, end).ListFormat.RemoveNumbers();
                        document2.Application.Selection.Find.ClearFormatting();
                        //document2.Application.Selection.Find.ClearFormatting();
                        document2.Application.Selection.Find.Execute("A.\t", ref missing, ref missing, ref missing, ref missing, ref missing, ref missing,
                                        ref missing, ref missing, "", WdReplace.wdReplaceAll, ref missing, ref missing,
                                        ref missing, ref missing);
                        document2.Application.Selection.Find.Execute("B.\t", ref missing, ref missing, ref missing, ref missing, ref missing, ref missing,
                            ref missing, ref missing, "", WdReplace.wdReplaceAll, ref missing, ref missing,
                            ref missing, ref missing);
                        document2.Application.Selection.Find.Execute("C.\t", ref missing, ref missing, ref missing, ref missing, ref missing, ref missing,
                            ref missing, ref missing, "", WdReplace.wdReplaceAll, ref missing, ref missing,
                            ref missing, ref missing);
                        document2.Application.Selection.Find.Execute("D.\t", ref missing, ref missing, ref missing, ref missing, ref missing, ref missing,
                            ref missing, ref missing, "", WdReplace.wdReplaceAll, ref missing, ref missing,
                            ref missing, ref missing);

                        document2.Application.Selection.Find.Execute("A.", ref missing, ref missing, ref missing, ref missing, ref missing, ref missing,
                            ref missing, ref missing, "", WdReplace.wdReplaceAll, ref missing, ref missing,
                            ref missing, ref missing);
                        document2.Application.Selection.Find.Execute("B.", ref missing, ref missing, ref missing, ref missing, ref missing, ref missing,
                            ref missing, ref missing, "", WdReplace.wdReplaceAll, ref missing, ref missing,
                            ref missing, ref missing);
                        document2.Application.Selection.Find.Execute("C.", ref missing, ref missing, ref missing, ref missing, ref missing, ref missing,
                            ref missing, ref missing, "", WdReplace.wdReplaceAll, ref missing, ref missing,
                            ref missing, ref missing);
                        document2.Application.Selection.Find.Execute("D.", ref missing, ref missing, ref missing, ref missing, ref missing, ref missing,
                            ref missing, ref missing, "", WdReplace.wdReplaceAll, ref missing, ref missing,
                            ref missing, ref missing);
                    }
                    */
                    if (clearFormat_checkBox.Checked == true)
                    {
                        //document2 = winword.Documents.Open(ref fileName, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref isVisible, ref missing, ref missing, ref missing, ref missing);
                        start = document2.Content.Start;
                        end = document2.Content.End;
                        document2.Range(start, end).Select();
                        document2.Application.Selection.ClearFormatting();//.Find.ClearFormatting();

                        //document2.SaveAs2(ref fileName);
                        //document2.Close(ref doNotSaveChanges, ref missing, ref missing);
                        //document3.Close(ref doNotSaveChanges, ref missing, ref missing);
                        //document = null;
                        //document2 = null;

                    }

                    questionTable = document2.Tables[1];
                    templateTable = document3.Tables[1];

                    //Add template to word
                    document.Activate();

                    //Add custom properties
                    dynamic properties = null;
                    try
                    {
                        properties = document.CustomDocumentProperties;

                        // Testing purposes:
                        if (language_comboBox.Text == "Tiếng Anh")
                        properties.Add("moodleLanguage", false, MsoDocProperties.msoPropertyTypeString, "en");
                        else
                            properties.Add("moodleLanguage", false, MsoDocProperties.msoPropertyTypeString, "vi");
                    }
                    finally
                    {
                        Marshal.ReleaseComObject(properties);
                    }

                    //Convert to Moodle Quiz
                    GenerateMoodleWord(templateTable, questionTable, document, txtPath.Text);

                    object template = Directory.GetCurrentDirectory().ToString() + "\\Template\\moodleStartup.dotm";
                    document.set_AttachedTemplate(template);
                    document.UpdateStyles();

                    //start = document.Content.Start;
                    //end = document.Content.End;
                    //document.Range(start, end).Select();
                    //document.Application.Selection.Find.ClearFormatting();

                    //Save the document  
                    string name = Path.GetFileNameWithoutExtension(txtPath.Text);
                    //name = ConvertToUnSign(name);
                    object filename = @txtSavePath.Text + "\\" + "[Converted]_" + name + ".docx";
                    document.SaveAs2(ref filename);
                }
                else
                {
                    capnhat.CloseWaitForm();
                    ktloi = true;
                    if (fixedRowNum.Checked == true)
                        MessageBox.Show("Dữ liệu không đủ!");
                }

                //Quit all process
                //Save change option
                object doNotSaveChanges = WdSaveOptions.wdDoNotSaveChanges;

                //Close word process
                document.Close(ref doNotSaveChanges, ref missing, ref missing);
                document2.Close(ref doNotSaveChanges, ref missing, ref missing);
                document3.Close(ref doNotSaveChanges, ref missing, ref missing);
                document = null;
                document2 = null;
                document3 = null;
                winword.Quit(ref doNotSaveChanges, ref missing, ref missing);
                winword = null;
                if (ktloi == false)
                {
                    capnhat.CloseWaitForm();
                    //MessageBox.Show("Đã tạo tệp thành công!", "Thông báo!");
                }
            }
            catch (Exception ex)
            {
                //Save change option
                object doNotSaveChanges = WdSaveOptions.wdDoNotSaveChanges;

                //Close word process
                document.Close(ref doNotSaveChanges, ref missing, ref missing);
                document2.Close(ref doNotSaveChanges, ref missing, ref missing);
                document3.Close(ref doNotSaveChanges, ref missing, ref missing);
                document = null;
                document2 = null;
                document3 = null;
                winword.Quit(ref doNotSaveChanges, ref missing, ref missing);
                winword = null;
                capnhat.CloseWaitForm();
                if (fixedRowNum.Checked == true)
                    MessageBox.Show(ex.Message);
            }
        }
        private int GenerateMoodleWord(Table tempTable, Table oriTable, Document doc, string path)
        {
            int k = 0, answer = 0;
            answer = chkAnswerInFile.Checked == true ? 1 : 0;
            if (chkFeedback.Checked)
            {
                k = 6 + answer;
            }
            else
            {
                k = 5 + answer;
            }

            object missing = Missing.Value;
            Paragraph para1 = doc.Content.Paragraphs.Add(ref missing);
            Table tarTable = doc.Tables.Add(para1.Range, 1, 1, ref missing, ref missing);
            tarTable.Rows[tarTable.Rows.Count].Delete();
            //Set right answer for each question
            int tableNum = oriTable.Rows.Count / k;
            string answerMarker = txtAnswer.Text;
            string answerList = "ABCDEF";
            //Add category to moodle quiz
            object styleHeading1 = "Heading 1";
            para1.Range.set_Style(ref styleHeading1);
            if (autoCatName.Checked == true)
                para1.Range.Text = ConvertToUnSign(Path.GetFileNameWithoutExtension(path));
            else
                para1.Range.Text = catName.Text;

            para1.Range.InsertParagraphAfter();
            //create list number of answer
            tarTable = null;
            int j = 0;
            //WaitForm1 wf = new WaitForm1();
            //wf.BringToFront();//.Top = true;
            //wf.Show();


            //wf.probar
            label4.Visible = true;
            probar1.Visible = true;

            //wf.progressBar1.Value = 0;                        
            probar1.Value = 0;
            //wf.progressBar1.Maximum = tableNum;
            //capnhat.ShowWaitForm();
            probar1.Maximum = tableNum;
            for (j = 1; j <= tableNum; j++)
            {
                //lblphantram.Text = "Tạo câu hỏi: " + j + " / " + tableNum;
                label4.Text = "Tạo câu hỏi: " + j + " / " + tableNum;
                probar1.Value++;
                //wf.progressBar1.Value++;
                //capnhat.ShowWaitForm();

                probar1.Refresh();
                //wf.progressBar1.Refresh();

                object styleHeading2 = "Heading 2";
                para1.Range.set_Style(ref styleHeading2);
                para1.Range.Text = "Câu hỏi " + j;
                para1.Range.InsertParagraphAfter();
                tarTable = doc.Tables.Add(para1.Range, 1, 1, ref missing, ref missing);
                CopyWord2Word(tempTable, tarTable);
                tarTable.Rows[tarTable.Rows.Count].Delete();

                tarTable.Rows[7].Cells[4].Range.Text = "0";

                if (!chkAnswerInFile.Checked)//đưa đáp án vào = ban phím
                {
                    string rightAnswer = answerMarker[j - 1].ToString().ToUpper();
                    int answerPosition = answerList.IndexOf(rightAnswer);
                    tarTable.Rows[7 + answerPosition].Cells[4].Range.Text = "100";
                }
            }
            j = 0;
            int delay1 = int.Parse(txtDelay.Text), delay2 = int.Parse(txtDelay2.Text);
            probar1.Value = 0;
            //wf.progressBar1.Value = 0;

            probar1.Maximum = tableNum;
            //wf.progressBar1.Maximum = tableNum;
            //capnhat.ShowWaitForm();

            for (int questionNum = 0; questionNum < tableNum; questionNum++) //đưa nội dung vào mẫu
            {
                probar1.Value++;
                //wf.progressBar1.Value++;

                probar1.Refresh();
                //wf.progressBar1.Refresh();
                //capnhat.ShowWaitForm();

                tarTable = doc.Tables[questionNum + 1];

                string right = oriTable.Rows[7 * questionNum + 6].Cells[1].Range.Text.Trim();
                right = right[0].ToString();

                tarTable.Rows[7 + answerList.IndexOf(right.ToUpper())].Cells[4].Range.Text = "100";//dap an dung
                bool copyPasted = false;
                while (copyPasted == false)
                {
                    try
                    {
                        copyPasted = true;
                        oriTable.Rows[7 * questionNum + 1].Cells[1].Range.Copy();//cau hoi
                        tarTable.Rows[1].Cells[1].Range.PasteSpecial();
                    }
                    catch (Exception e)
                    {
                        Clipboard.Clear();
                        System.Threading.Thread.Sleep(delay2);
                        copyPasted = false;
                        MessageBox.Show(e.ToString());
                    }

                }
                //System.Threading.Thread.Sleep(delay2);

                copyPasted = false;
                while (copyPasted == false)
                {
                    try
                    {
                        copyPasted = true;
                        oriTable.Rows[7 * questionNum + 2].Cells[1].Range.Copy();
                        tarTable.Rows[7].Cells[2].Range.PasteSpecial();
                        //tarTable.Rows[7].Cells[2].Range.PasteSpecial();
                    }
                    catch (Exception e)
                    {
                        Clipboard.Clear();
                        System.Threading.Thread.Sleep(delay2);
                        copyPasted = false;
                        MessageBox.Show(e.ToString());
                    }

                }
                //System.Threading.Thread.Sleep(delay1);

                copyPasted = false;
                while (copyPasted == false)
                {
                    try
                    {
                        copyPasted = true;
                        oriTable.Rows[7 * questionNum + 3].Cells[1].Range.Copy();
                        tarTable.Rows[8].Cells[2].Range.PasteSpecial();
                    }
                    catch (Exception e)
                    {
                        Clipboard.Clear();
                        System.Threading.Thread.Sleep(delay2);
                        copyPasted = false;
                        MessageBox.Show(e.ToString());
                    }

                }
                //System.Threading.Thread.Sleep(delay2);

                copyPasted = false;
                while (copyPasted == false)
                {
                    try
                    {
                        copyPasted = true;
                        oriTable.Rows[7 * questionNum + 4].Cells[1].Range.Copy();
                        tarTable.Rows[9].Cells[2].Range.PasteSpecial();
                    }
                    catch (Exception e)
                    {
                        Clipboard.Clear();
                        System.Threading.Thread.Sleep(delay2);
                        copyPasted = false;
                        MessageBox.Show(e.ToString());
                    }

                }
                //System.Threading.Thread.Sleep(delay1);

                copyPasted = false;
                while (copyPasted == false)
                {
                    try
                    {
                        copyPasted = true;
                        oriTable.Rows[7 * questionNum + 5].Cells[1].Range.Copy();
                        tarTable.Rows[10].Cells[2].Range.PasteSpecial();
                    }
                    catch (Exception e)
                    {
                        Clipboard.Clear();
                        System.Threading.Thread.Sleep(delay2);
                        copyPasted = false;
                        MessageBox.Show(e.ToString());
                    }

                }

                copyPasted = false;
                //System.Threading.Thread.Sleep(delay2);
                while (copyPasted == false)
                {
                    try
                    {
                        copyPasted = true;
                        oriTable.Rows[7 * questionNum + 7].Cells[1].Range.Copy();
                        tarTable.Rows[12].Cells[3].Range.PasteSpecial();
                    }
                    catch (Exception e)
                    {
                        Clipboard.Clear();
                        System.Threading.Thread.Sleep(delay2);
                        copyPasted = false;
                        MessageBox.Show(e.ToString());
                    }

                }
                Clipboard.Clear();
                GC.Collect();
                System.Threading.Thread.Sleep(delay1);
                //lblphantram.Text = "Tạo chi tiết câu hỏi: " + probar1.Value.ToString() + " / " + probar1.Maximum.ToString();
                label4.Text = "Tạo chi tiết câu hỏi: " + probar1.Value.ToString() + " / " + probar1.Maximum.ToString();
            }
            probar1.Visible = false;
            label4.Visible = false;
            //wf.Close();
            return 1;
        }
        public static string ConvertToUnSign(string s)
        {
            Regex regex = new Regex("\\p{IsCombiningDiacriticalMarks}+");
            string temp = s.Normalize(NormalizationForm.FormD);
            return regex.Replace(temp, String.Empty).Replace('\u0111', 'd').Replace('\u0110', 'D');
        }
        private void CopyWord2Word(Table oriTable, Table tarTable)
        {
            bool copyPasted = false;
            while (copyPasted == false)
            {
                try
                {
                    copyPasted = true;
                    oriTable.Range.Copy();
                    tarTable.Range.PasteSpecial();
                }
                catch (Exception e)
                {
                    Clipboard.Clear();
                    System.Threading.Thread.Sleep(int.Parse(txtDelay.Text));
                    copyPasted = false;
                    MessageBox.Show(e.ToString());
                }

            }

            
            //Clipboard.Clear();
            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void catName_TextChanged(object sender, EventArgs e)
        {
            //autoCatName.Checked = false;
        }

        private void catName_MouseClick(object sender, MouseEventArgs e)
        {
            autoCatName.Checked = false;
        }
    }
}