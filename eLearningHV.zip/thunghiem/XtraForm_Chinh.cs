﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace unzipPackage.thunghiem
{
    public partial class XtraForm_Chinh : DevExpress.XtraEditors.XtraForm
    {
        public XtraForm_Chinh()
        {
            InitializeComponent();
        }

        private void XtraForm_Chinh_Load(object sender, EventArgs e)
        {

        }
    }
}