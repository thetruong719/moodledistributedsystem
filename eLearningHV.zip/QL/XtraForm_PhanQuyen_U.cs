﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace unzipPackage.QL
{
    public partial class XtraForm_PhanQuyen_U : DevExpress.XtraEditors.XtraForm
    {
        public XtraForm_PhanQuyen_U()
        {
            InitializeComponent();
        }
    }
}